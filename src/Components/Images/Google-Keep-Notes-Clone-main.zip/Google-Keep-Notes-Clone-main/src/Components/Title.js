import React from 'react'

export default function Title() {
  return (
    <div className='title'>
        <h5>Keep</h5>
    </div>
  )
}
